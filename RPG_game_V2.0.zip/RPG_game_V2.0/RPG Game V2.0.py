import math
import random
import shelve
import sys
import time
import pygame


def adventure():
    page = 1
    adventure_stage = -1

    while True:

        main_menu_text = font.render("Main Menu", True, "white")
        next_page_text = font.render("Next Page", True, "White")
        previous_page_text = font.render("Previous Page", True, "White")
        item_font = pygame.font.Font("pixel font.TTF", 20)
        screen.blit(background, (0, 0))

        for x in range(min(4, len(cleared_stages) + 1 - 4 * (page - 1))):
            pygame.draw.rect(screen, "black", pygame.Rect(100, 80 + 80 * x, 200, 40))
            stage_text = item_font.render(f"Stage {x + 1 + 4 * (page - 1)}", True, "White")
            screen.blit(stage_text, (110, 90 + 80 * x))

        pygame.draw.rect(screen, "black", pygame.Rect(100, 400, 200, 40))

        if (page - 1) * 4 > 0:
            pygame.draw.rect(screen, "black", pygame.Rect(350, 400, 220, 40))
            screen.blit(previous_page_text, (360, 405))

        if len(cleared_stages) - ((page - 1) * 4) >= 4:
            pygame.draw.rect(screen, "black", pygame.Rect(600, 400, 150, 40))
            screen.blit(next_page_text, (605, 405))

        screen.blit(main_menu_text, (130, 405))

        if adventure_stage > -1:

            pygame.draw.rect(screen, "black", pygame.Rect(350, 90, 400, 300))
            item_name_text = font.render(f"enemy HP  {enemy_hp}", True, "White")
            screen.blit(item_name_text, (360, 120))
            item_type_text = font.render(f"enemy  ATK  {enemy_atk}", True, "White")
            screen.blit(item_type_text, (360, 190))
            equip_text = font.render("FIGHT", True, "Yellow")
            screen.blit(equip_text, (510, 350))

        pygame.display.update()

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:

                click = pygame.mouse.get_pressed()[0]

                if click:

                    if pygame.mouse.get_pos()[0] in range(100, 300) and pygame.mouse.get_pos()[1] in range(400, 440):

                        return 0

                    if pygame.mouse.get_pos()[0] in range(350, 560) and pygame.mouse.get_pos()[1] in range(400,
                                                                                                           440) and page > 1:
                        page -= 1
                        adventure_stage = -1

                    if pygame.mouse.get_pos()[0] in range(600, 750) and pygame.mouse.get_pos()[1] in range(400,
                                                                                                           440) and len(cleared_stages) - ((page - 1) * 4) >= 4:
                        page += 1
                        adventure_stage = -1

                    if pygame.mouse.get_pos()[0] in range(505, 590) and pygame.mouse.get_pos()[1] in range(350,
                                                                                                           380) and adventure_stage > -1:
                        return fight(_hp + _armor[2] + _boot[2], _atk + _sword[2], enemy_hp, enemy_atk, adventure_stage)

                    for x in range(min(4, len(cleared_stages) + 1 - 4 * (page - 1))):
                        if pygame.mouse.get_pos()[0] in range(100, 300) and pygame.mouse.get_pos()[1] in range(
                                80 + 80 * x, 120 + 80 * x):
                            adventure_stage = x + 1 + (page - 1) * 4
                            enemy_hp = adventure_stage*16+math.floor(math.sqrt(adventure_stage*20))
                            enemy_atk = adventure_stage*3+math.floor(math.sqrt(adventure_stage*10))


# Fight function for the battle which takes the user's total health and attack and enemy's health and attack and stage
# and reduces the health of each by the damage of the other for each round until one of them dies (hp less than 0)
def fight(hp, base_atk, enemy_hp, base_enemy_atk, _stage):

    # Battle loop while health of the player or the enemy isn't 0 or less it'll continue
    # Note: the user always starts first
    base_enemy_hp = enemy_hp
    base_hp = hp
    fight_font = pygame.font.Font("pixel font.TTF", 25)
    while hp > 0 and enemy_hp > 0:

        # Generates random attack within the range of (atk - square root of the atk) to atk
        # for each of the enemy and the player
        screen.fill("LightBlue")
        pygame.draw.rect(screen, "Green", pygame.Rect(0, 400, 800, 500))
        pygame.draw.rect(screen, "Blue", pygame.Rect(300, 360, 20, 40))
        pygame.draw.rect(screen, "Red", pygame.Rect(500, 360, 20, 40))
        pygame.draw.rect(screen, "Black", pygame.Rect(280, 340, 60, 10))
        pygame.draw.rect(screen, "Black", pygame.Rect(480, 340, 60, 10))
        pygame.draw.rect(screen, ((1-(hp/base_hp))*255, 255*(hp/base_hp), 0), pygame.Rect(280, 340, 60*(hp/base_hp), 10))
        pygame.draw.rect(screen, ((1-(enemy_hp/base_enemy_hp))*255, 255*(enemy_hp/base_enemy_hp), 0), pygame.Rect(480, 340, 60*(enemy_hp/base_enemy_hp), 10))
        enemy_atk = random.randint(math.floor(base_enemy_atk - math.sqrt(base_enemy_atk)), base_enemy_atk)
        atk = random.randint(math.floor(base_atk - math.sqrt(base_atk)), base_atk)
        enemy_hp -= atk
        time.sleep(1)
        damage_text = fight_font.render(f"{atk}", True, "White")
        screen.blit(damage_text, (500, 310))
        pygame.display.update()

        # Checks if the enemy's hp is higher than 0 before the enemy attacks the user if yes then it breaks the loop
        if enemy_hp <= 0:

            time.sleep(1)
            screen.fill("LightBlue")
            gold = random.randint(math.floor((5 * _stage) / 2), 6 * _stage - math.floor(math.sqrt(_stage * 2)))
            pygame.draw.rect(screen, "Green", pygame.Rect(0, 400, 800, 500))
            pygame.draw.rect(screen, "Blue", pygame.Rect(300, 360, 20, 40))
            pygame.draw.rect(screen, "Red", pygame.Rect(500, 360, 20, 40))
            pygame.draw.rect(screen, "Black", pygame.Rect(280, 340, 60, 10))
            pygame.draw.rect(screen, "Black", pygame.Rect(480, 340, 60, 10))
            pygame.draw.rect(screen, ((1 - (hp / base_hp)) * 255, 255 * (hp / base_hp), 0),
                             pygame.Rect(280, 340, 60 * (hp / base_hp), 10))
            pygame.draw.rect(screen, (255, 0, 0),
                             pygame.Rect(480, 340, 0, 10))
            gold_gained_text = font.render(f"GOLD {gold}", True, "Yellow")
            victory_text = font.render("VICTORY", True, "Green")
            screen.blit(victory_text, (350, 50))
            screen.blit(gold_gained_text, (360, 150))
            pygame.display.update()
            time.sleep(2)
            cleared_stages.add(_stage)
            return gold

        time.sleep(1)
        screen.fill("LightBlue")
        pygame.draw.rect(screen, "Green", pygame.Rect(0, 400, 800, 500))
        pygame.draw.rect(screen, "Blue", pygame.Rect(300, 360, 20, 40))
        pygame.draw.rect(screen, "Red", pygame.Rect(500, 360, 20, 40))
        pygame.draw.rect(screen, "Black", pygame.Rect(280, 340, 60, 10))
        pygame.draw.rect(screen, "Black", pygame.Rect(480, 340, 60, 10))
        pygame.draw.rect(screen, ((1 - (hp / base_hp)) * 255, 255 * (hp / base_hp), 0),
                         pygame.Rect(280, 340, 60 * (hp / base_hp), 10))
        pygame.draw.rect(screen, ((1 - (enemy_hp / base_enemy_hp)) * 255, 255 * (enemy_hp / base_enemy_hp), 0),
                         pygame.Rect(480, 340, 60 * (enemy_hp / base_enemy_hp), 10))
        hp -= enemy_atk
        damage_text = fight_font.render(f"{enemy_atk}", True, "White")
        screen.blit(damage_text, (300, 310))
        pygame.display.update()
        time.sleep(1)

    if hp <= 0:

        screen.fill("LightBlue")
        pygame.draw.rect(screen, "Green", pygame.Rect(0, 400, 800, 500))
        pygame.draw.rect(screen, "Blue", pygame.Rect(300, 360, 20, 40))
        pygame.draw.rect(screen, "Red", pygame.Rect(500, 360, 20, 40))
        pygame.draw.rect(screen, "Black", pygame.Rect(280, 340, 60, 10))
        pygame.draw.rect(screen, "Black", pygame.Rect(480, 340, 60, 10))
        pygame.draw.rect(screen, (255, 0, 0),pygame.Rect(280, 340, 0, 10))
        pygame.draw.rect(screen, ((1 - (enemy_hp / base_enemy_hp)) * 255, 255 * (enemy_hp / base_enemy_hp), 0),
                         pygame.Rect(480, 340, 60 * (enemy_hp / base_enemy_hp), 10))
        defeat_text = font.render("DEFEAT", True, "Red")
        screen.blit(defeat_text, (350, 50))
        pygame.display.update()
        time.sleep(2)
        return 0



def inventory(_sword, _armor, _boot):
    page = 1
    item_index = -1

    while True:

        main_menu_text = font.render("Main Menu", True, "white")
        next_page_text = font.render("Next Page", True, "White")
        previous_page_text = font.render("Previous Page", True, "White")
        item_font = pygame.font.Font("pixel font.TTF", 20)
        screen.blit(background, (0, 0))

        for x in range(min(4, len(user_items) - 4 * (page - 1))):
            pygame.draw.rect(screen, "black", pygame.Rect(100, 80 + 80 * x, 200, 40))
            item_text = item_font.render(user_items[x + (page - 1) * 4][0], True, "White")
            screen.blit(item_text, (110, 90 + 80 * x))

        pygame.draw.rect(screen, "black", pygame.Rect(100, 400, 200, 40))

        if (page - 1) * 4 > 0:
            pygame.draw.rect(screen, "black", pygame.Rect(350, 400, 220, 40))
            screen.blit(previous_page_text, (360, 405))

        if len(user_items) - ((page - 1) * 4) > 4:
            pygame.draw.rect(screen, "black", pygame.Rect(600, 400, 150, 40))
            screen.blit(next_page_text, (605, 405))

        screen.blit(main_menu_text, (130, 405))

        if item_index > -1:

            if user_items[item_index][1] == "Sword":

                stats = "Attack"

            else:

                stats = "HP"

            pygame.draw.rect(screen, "black", pygame.Rect(350, 90, 400, 300))
            item_name_text = font.render(f"{user_items[item_index][0]}", True, "White")
            screen.blit(item_name_text, (360, 100))
            item_type_text = font.render(f"Type  {user_items[item_index][1]}", True, "White")
            screen.blit(item_type_text, (360, 150))
            item_stats_text = font.render(f"{stats}  {user_items[item_index][2]}", True, "White")
            screen.blit(item_stats_text, (360, 200))
            equip_text = font.render("EQUIP", True, "Yellow")
            screen.blit(equip_text, (510, 350))

        pygame.display.update()

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:

                click = pygame.mouse.get_pressed()[0]

                if click:

                    if pygame.mouse.get_pos()[0] in range(100, 300) and pygame.mouse.get_pos()[1] in range(400, 440):

                        return _sword, _armor, _boot

                    if pygame.mouse.get_pos()[0] in range(350, 560) and pygame.mouse.get_pos()[1] in range(400,
                                                                                                           440) and page > 1:
                        page -= 1
                        item_index = -1

                    if pygame.mouse.get_pos()[0] in range(600, 750) and pygame.mouse.get_pos()[1] in range(400,
                                                                                                           440) and page == 1:
                        page += 1
                        item_index = -1

                    if pygame.mouse.get_pos()[0] in range(505, 600) and pygame.mouse.get_pos()[1] in range(350,
                                                                                                           380) and item_index > -1:
                        if(user_items[item_index][1] == "Sword"):

                            user_items.append(_sword)
                            _sword = user_items[item_index]
                            user_items.pop(item_index)

                        elif(user_items[item_index][1] == "Armor"):

                            user_items.append(_armor)
                            _armor = user_items[item_index]
                            user_items.pop(item_index)

                        else:

                            user_items.append(_boot)
                            _boot = user_items[item_index]
                            user_items.pop(item_index)

                        item_index = -1

                    for x in range(min(4, len(user_items) - 4 * (page - 1))):
                        if pygame.mouse.get_pos()[0] in range(100, 300) and pygame.mouse.get_pos()[1] in range(
                                80 + 80 * x, 120 + 80 * x):
                            item_index = x + (page - 1) * 4


def stats():
    attack_text = font.render(f"Attack    {_atk + _sword[2]}", True, "White")
    hp_text = font.render(f"HP    {_hp + _armor[2] + _boot[2]}", True, "White")
    gold_text = font.render(f"Gold    {_gold}", True, "White")

    while True:

        main_menu_text = font.render("Main Menu", True, "white")
        screen.blit(background, (0, 0))
        pygame.draw.rect(screen, "black", pygame.Rect(100, 400, 200, 40))
        pygame.draw.rect(screen, "black", pygame.Rect(350, 40, 400, 400))
        screen.blit(attack_text, (400, 80))
        screen.blit(hp_text, (400, 160))
        screen.blit(gold_text, (400, 240))
        screen.blit(main_menu_text, (130, 405))
        pygame.display.update()

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:

                click = pygame.mouse.get_pressed()[0]

                if click:

                    if pygame.mouse.get_pos()[0] in range(100, 300) and pygame.mouse.get_pos()[1] in range(400, 440):
                        return 0


def shop(_gold):
    page = 1
    item_index = -1

    while True:

        main_menu_text = font.render("Main Menu", True, "white")
        gold_text = font.render(f"{_gold}", True, "Yellow")
        next_page_text = font.render("Next Page", True, "White")
        previous_page_text = font.render("Previous Page", True, "White")
        item_font = pygame.font.Font("pixel font.TTF", 20)
        screen.blit(background, (0, 0))

        for x in range(min(4, len(items) - 4 * (page - 1))):
            pygame.draw.rect(screen, "black", pygame.Rect(100, 80 + 80 * x, 200, 40))
            item_text = item_font.render(items[x + (page - 1) * 4][0], True, "White")
            screen.blit(item_text, (110, 90 + 80 * x))

        pygame.draw.rect(screen, "black", pygame.Rect(100, 400, 200, 40))

        if (page - 1) * 4 > 0:
            pygame.draw.rect(screen, "black", pygame.Rect(350, 400, 220, 40))
            screen.blit(previous_page_text, (360, 405))

        if len(items) - ((page - 1) * 4) > 4:
            pygame.draw.rect(screen, "black", pygame.Rect(600, 400, 150, 40))
            screen.blit(next_page_text, (605, 405))

        pygame.draw.circle(screen, "Yellow", (675, 60), 10)
        screen.blit(gold_text, (700, 45))
        screen.blit(main_menu_text, (130, 405))

        if item_index > -1:

            if items[item_index][1] == "Sword":

                stats = "Attack"

            else:

                stats = "HP"

            pygame.draw.rect(screen, "black", pygame.Rect(350, 90, 400, 300))
            item_name_text = font.render(f"{items[item_index][0]}", True, "White")
            screen.blit(item_name_text, (360, 100))
            item_type_text = font.render(f"Type  {items[item_index][1]}", True, "White")
            screen.blit(item_type_text, (360, 150))
            item_cost_text = font.render(f"Price  {items[item_index][2]}", True, "White")
            screen.blit(item_cost_text, (360, 200))
            item_stats_text = font.render(f"{stats}  {items[item_index][3]}", True, "White")
            screen.blit(item_stats_text, (360, 250))
            buy_text = font.render("BUY", True, "Yellow")
            screen.blit(buy_text, (525, 350))

        pygame.display.update()

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:

                click = pygame.mouse.get_pressed()[0]

                if click:

                    if pygame.mouse.get_pos()[0] in range(100, 300) and pygame.mouse.get_pos()[1] in range(400, 440):
                        return _gold

                    if pygame.mouse.get_pos()[0] in range(350, 560) and pygame.mouse.get_pos()[1] in range(400,
                                                                                                           440) and page > 1:
                        page -= 1
                        item_index = -1

                    if pygame.mouse.get_pos()[0] in range(600, 750) and pygame.mouse.get_pos()[1] in range(400,
                                                                                                           440) and page == 1:
                        page += 1
                        item_index = -1

                    if pygame.mouse.get_pos()[0] in range(520, 580) and pygame.mouse.get_pos()[1] in range(350,
                                                                                                           380) and item_index > -1:

                        if _gold - items[item_index][2] < 0:

                            error_text = font.render("Not enough gold", True, "Red")
                            screen.blit(error_text, (300, 235))
                            pygame.display.update()
                            time.sleep(1)

                        else:

                            _gold -= items[item_index][2]
                            user_items.append([items[item_index][0], items[item_index][1], items[item_index][3]])
                            items.pop(item_index)
                            item_index = -1

                    for x in range(min(4, len(items) - 4 * (page - 1))):
                        if pygame.mouse.get_pos()[0] in range(100, 300) and pygame.mouse.get_pos()[1] in range(
                                80 + 80 * x, 120 + 80 * x):
                            item_index = x + (page - 1) * 4


# Save function for storing the user's data
# it works using shelve library
def save():
    # Opens the save file
    save_file = shelve.open("User_Data")
    # Saves each variable in the file with their keyword
    save_file["stage"] = cleared_stages
    save_file["hp"] = _hp
    save_file["atk"] = _atk
    save_file["gold"] = _gold
    save_file["user_items"] = user_items
    save_file["armor"] = _armor
    save_file["boot"] = _boot
    save_file["sword"] = _sword
    save_file["items"] = items
    # Closes the file
    save_file.close()


# A function for loading the data which were saved if there was no data saved it creates a file to save the data in
# and returns the default (starting) values to each variable
def load_files():
    # Opens the file (creates a file if there is none)
    save_file = shelve.open("User_Data")

    try:

        # Checks if there is a save variable in this keyword if there is one it loads the data from each keyword
        # to it's variable and prints "welcome back to FAR"
        # If there's no data it'll give an error which will make the except case run
        # which prints "Welcome to FAR" then prints the tutorials then waits for user to press enter
        # then returns the defaults of each variable
        check_save_file = save_file["stage"]
        del check_save_file
        start = time.time()
        font = pygame.font.Font("pixel font.TTF", 70)
        welcome_back_text = font.render("Welcome back to FAR", True, "White")
        while time.time() - start < 3:
            screen.blit(background, (0, 0))
            screen.blit(welcome_back_text, (90, 200))
            pygame.display.update()

        return save_file["stage"], save_file["hp"], save_file["atk"], save_file["gold"], save_file["user_items"], \
               save_file["armor"], save_file["boot"], save_file["sword"], save_file["items"]

    except:

        start = time.time()
        font = pygame.font.Font("pixel font.TTF", 70)
        welcome_text = font.render("Welcome to FAR", True, "White")
        while time.time() - start < 3:
            screen.blit(background, (0, 0))
            screen.blit(welcome_text, (160, 200))
            pygame.display.update()

        return set(), 50, 10, 0, [], ["Framer Clothes", "Armor", 0], ["Farmer Boots", "Boots", 0], \
               ["Farmer Hoe", "Sword", 0], [["Starter Sword", "Sword", 10, 10],
                                            ["Apprentice Sword", "Sword", 25, 20],
                                            ["Starter Armor", "Armor", 15, 50],
                                            ["Apprentice Armor", "Armor", 35, 100],
                                            ["Started Boots", "Boots", 5, 20],
                                            ["Apprentice Boots", "Boots", 15, 50]]


pygame.init()
screen = pygame.display.set_mode((800, 500))
font = pygame.font.Font("pixel font.TTF", 30)
logo = pygame.image.load("logo.png").convert()
background = pygame.image.load("background.png").convert()
size = pygame.display.get_window_size()
background = pygame.transform.scale(background, size)
pygame.display.set_caption("FAR")
pygame.display.set_icon(logo)
clock = pygame.time.Clock()

cleared_stages, _hp, _atk, _gold, user_items, _armor, _boot, _sword, items = load_files()
adventure_text = font.render("Adventure", True, "white")
inventory_text = font.render("Inventory", True, "white")
stats_text = font.render("Stats", True, "White")
shop_text = font.render("Shop", True, "White")
quit_text = font.render("Quit", True, "white")

while True:

    screen.blit(background, (0, 0))
    for x in range(5):
        pygame.draw.rect(screen, "black", pygame.Rect(100, 80 + 80 * x, 200, 40))

    screen.blit(adventure_text, (125, 85))
    screen.blit(inventory_text, (125, 165))
    screen.blit(stats_text, (165, 245))
    screen.blit(shop_text, (170, 325))
    screen.blit(quit_text, (175, 405))
    pygame.display.update()

    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            save()
            sys.exit()

        if event.type == pygame.MOUSEBUTTONDOWN:

            click = pygame.mouse.get_pressed()[0]

            if click:

                if pygame.mouse.get_pos()[0] in range(100, 300) and pygame.mouse.get_pos()[1] in range(80, 120):

                    _gold += adventure()
                    save()

                elif pygame.mouse.get_pos()[0] in range(100, 300) and pygame.mouse.get_pos()[1] in range(160, 200):

                    _sword, _armor, _boot = inventory(_sword, _armor, _boot)
                    save()

                elif pygame.mouse.get_pos()[0] in range(100, 300) and pygame.mouse.get_pos()[1] in range(240, 280):

                    stats()

                elif pygame.mouse.get_pos()[0] in range(100, 300) and pygame.mouse.get_pos()[1] in range(320, 360):

                    _gold = shop(_gold)
                    save()

                elif pygame.mouse.get_pos()[0] in range(100, 300) and pygame.mouse.get_pos()[1] in range(400, 440):

                    save()
                    sys.exit()

    clock.tick(60)
